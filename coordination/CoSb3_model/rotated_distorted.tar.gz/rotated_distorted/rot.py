from e3nn.o3 import rand_matrix
import torch
import numpy as np

cell = """
  -4.52757000   4.52757000   4.52757000
   4.52757000  -4.52757000   4.52757000
   4.52757000   4.52757000  -4.52757000
"""
cell = np.array(cell.split(),dtype=float).reshape((3,3))
cell = torch.from_numpy(cell)
print(cell)
print(torch.norm(cell, dim = 1))

cell = torch.einsum('ij,zj -> zi', rand_matrix().float(), cell.float())
for lv in cell:
    print(" {:>10.5f}{:>10.5f}{:>10.5f}".format(*lv))
print(torch.norm(cell, dim = 1))

cell = torch.einsum('ij,zj -> zi', rand_matrix().float(), cell.float())
for lv in cell:
    print(" {:>10.5f}{:>10.5f}{:>10.5f}".format(*lv))
print(torch.norm(cell, dim = 1))