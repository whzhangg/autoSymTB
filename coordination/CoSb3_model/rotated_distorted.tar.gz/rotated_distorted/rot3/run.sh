#!/bin/bash
#QSUB2 queue qM
#QSUB2 core 96 
#QSUB2 mpi 96
#QSUB2 smp 1
#QSUB2 wtime 48:00:00
#PBS -N whzjob
cd $PBS_O_WORKDIR
source /etc/profile.d/modules.sh
source ~/.env_control.sh

export PATH=$PATH:/home/whzhang/work/packages/qe-6.8/bin
export PATH=$PATH:/home/whzhang/work/packages/my_bin

module-load-general
mpirun pw.x -npool 12 -in scf.in > scf.out
mpirun -np 12 projwfc.x -in proj.in > proj.out 

rm -rf out
if [ -e *.projwfc_up ] 
  then
  touch "OK.txt"
  rm *.projwfc_up
  rm *.projwfc_down
fi

